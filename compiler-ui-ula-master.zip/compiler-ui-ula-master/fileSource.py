i1 = 1
i2 = "jose"
i = [i1 , i2 ]
print(i)
i = [i1 ,        i2 ]
print(i)
